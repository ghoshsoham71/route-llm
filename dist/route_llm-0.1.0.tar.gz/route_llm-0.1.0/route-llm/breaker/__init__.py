# llm_router/breaker/__init__.py
from .circuit import CircuitBreaker

__all__ = ["CircuitBreaker"]
